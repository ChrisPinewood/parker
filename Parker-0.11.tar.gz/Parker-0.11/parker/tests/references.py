#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Tests related to references in a document
"""

import re
from parker.document import find_in_full_text, get_section_index, get_sections, find_in_doc_slice, in_section
from parker.penelope_com import tell_penelope, TestResult, print_to_console
from parker.helpers.references import *


### MAIN TESTS FOR PENELOPE
def has_num_references(text, report_immediately=True):
    """ Check that there are numeric references in the reference section """
    reference_section_index = get_section_index(text, "references")

    result = None
    if reference_section_index:
        # run our regex only on the references section
        match_num_ref = re.compile('^[#*_]*\d+\. *.*?$', flags=re.MULTILINE)
        results = find_in_doc_slice(match_num_ref, text, reference_section_index, reference_section_index + 1, 'has_num_references', report_immediately)
        if len(results) < 1:
            result = TestResult('has_num_references', False)
        else:
            result = TestResult('has_num_references', True)

    if result:
        if report_immediately:
            tell_penelope(result)
        return [result]



def find_all_references(text, report_immediately=True):
    """ Find both sorts of references, and returns both"""
    res = []
    res.extend(find_num_references(text, report_immediately))
    res.extend(find_alpha_references(text, report_immediately))
    return res

def find_dates_in_references(full_text, report_immediately=True):
    """Pull out dates from the reference section. This is mainly to demonstrate some of the workflow features in document.py """
    match_dates = re.compile(r'\b\d{4}(?!\d)')
    reference_section_index = get_section_index(full_text, "references")
    (titles, indexes) = get_sections(full_text)

    results = None
    if reference_section_index:
        # store the actual title for the references section
        ref_title = titles[reference_section_index]

        # now run our regex only on the references section
        results = find_in_doc_slice(match_dates, full_text, reference_section_index, reference_section_index + 1, 'find_dates_in_references', report_immediately)

    # bonus check: make sure each of these matches is actually from the references section.
    if results:
        for r in results:
            if r.passed:
                (s, e) = r.position
                assert in_section(e, full_text, (titles, indexes)) is ref_title
    return results

def find_reference_section(text, report_immediately=True):
    """ The main functions we run to check that references section exist """
    results = []
    heading_regex = re.compile(r"[\*\#\_]+(?:\s)?references?(?:\s)?[\*\#\_]+", flags = re.DOTALL | re.MULTILINE | re.IGNORECASE)
    r = heading_regex.search(text);
    if r:
        (s, e) = r.span()
        result = TestResult('find_reference_section', True, position=r.span())
        results.append(result)
        if report_immediately:
            tell_penelope(result)
    else:
        result = TestResult('find_reference_section', False)
        results.append(result)
        if report_immediately:
            tell_penelope(result)

    if results:
        return results
    else:
        result = TestResult('find_reference_section', True)
        if report_immediately:
            tell_penelope(result)
        return [result]


def verify_references_in_citations(text, report_immediately=True):
    """ The main functions we run to check that references section contains found citations """

    heading_regex = re.compile(r"[\*\#\_]+(?:\s)?references?(?:\s)?[\*\#\_]+", flags = re.DOTALL | re.MULTILINE | re.IGNORECASE)

    results = []
    res = heading_regex.finditer(text)
    for r in res:
        (s, e) = r.span()

        main_body = text[0:s]
        references = text[e:len(text)]

        match_ref = re.compile(r'^[#*_]*\d+\. *.*?$', flags=re.MULTILINE)
        cit_nums = get_citation_numbers(main_body)
        ints = []
        results = []
        refres = match_ref.finditer(text)
        for ref in refres:
            (refs, refe) = ref.span()

            num = re.search('\d+', ref.group()).group()
            if int(num) not in cit_nums and refs > e:
                result = TestResult('verify_references_in_citations', False, position=(refs, refe))
                results.append(result)
                if report_immediately:
                    tell_penelope(result)

    if results:
        return results
    else:
        result = TestResult('verify_references_in_citations', True)
        if report_immediately:
            tell_penelope(result)
        return [result]


### SUPPLEMENTARY TESTS

def find_num_references(text, report_immediately=True):
    """ find references starting with a number """
    match_num_ref = re.compile('^[#*_]*\d+\. *.*?$', flags=re.MULTILINE)
    return find_in_full_text(match_num_ref, text, 'find_num_references', report_immediately)


def find_alpha_references(text, report_immediately=True):
    """ find references organised alphabetically """
    names = "(?:[.a-zA-Z' ,-]+)"
    match_alpha_ref = re.compile("^%s\(\d{4}\).*(?=\s)$" % names, flags=re.MULTILINE)
    return find_in_full_text(match_alpha_ref, text, 'find_alpha_references', report_immediately)


def verify_num_reference_seq(text):
    """
    Check the reference numerical sequence is correct
    :param text: the full text, or reference section
    """

    ints = get_reference_numbers(text)
    sorted_ints = sorted(ints)
    results = []

    # Check if we see the references in the right order
    if sorted_ints != ints:
        result = TestResult('verify_num_reference_seq:numerical_order', False)
        tell_penelope(result)
        results.append(result)
        print_to_console("Reference numerical order: (a) reference numbers / (b) sorted reference numbers")
        print_to_console('(a) ' + str(ints))
        print_to_console('(b) ' + str(sorted_ints))

    # Check there are no missing references
    if range(sorted_ints[0], sorted_ints[-1] + 1) != sorted_ints:
        result = TestResult('verify_num_reference_seq:full_sequence', False)
        tell_penelope(result)
        results.append(result)
        print_to_console("Full reference sequence: (a) reference numbers / (b) range from min to max")
        print_to_console('(a) ' + str(sorted_ints))
        print_to_console('(b) ' + str(range(sorted_ints[0], sorted_ints[-1] + 1)))

    # Check there are no repeated reference numbers
    if len(ints) != len(set(ints)):
        result = TestResult('verify_num_reference_seq:duplicate_numbers', False)
        tell_penelope(result)
        results.append(result)
        print_to_console("Duplicate reference numbers:\n" + str(ints))

    # We only have results if the checks failed; report these or return a successful result
    if results:
        return results
    else:
        result = TestResult('verify_num_reference_seq', True)
        tell_penelope(result)
        return [result]
