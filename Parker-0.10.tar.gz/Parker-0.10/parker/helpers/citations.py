#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Tests for a variety of citation styles.
Note: this file is explicitly encoded utf-8 because of the specific use of dash/hyphen symbols : - –
"""


from parker.penelope_com import TestResult, print_to_console
from nltk.tokenize.regexp import wordpunct_tokenize
from parker.data import stopwords
import re

def check_citation_style(text):
    """
    Check which citation style a document uses, by finding which regex counts the most matches
    :param text: the text we are checking for citations
    :return: a str identifier for which style
    """
    res_apa = find_apa_citations_name_prefix(text, False)
    res_num = find_numbered_citations(text, False)
    res_sup = find_superscript_citations(text, False)

    cit_style = ''
    res_best = max(res_apa, res_num, res_sup, key=len)
    if res_best == res_apa:
        print_to_console("APA style")
        cit_style = 'apa'
    elif res_best == res_num:
        print_to_console("numerical style")
        cit_style = 'num'
    elif res_best == res_sup:
        print_to_console("superscript style")
        cit_style = 'sup'

    return cit_style, res_best


def filter_apa_citation_matches(apa_matches, text):
    """Inspect our results for APA citations, remove any that don't look right."""

    refined_matches = []

    for match in apa_matches:
        if type(match) is not TestResult or not match.passed:
            break
        else:
            match_str = match.match_string(text)
            tokens = wordpunct_tokenize(match_str)
            tokens_non_stop = pop_stopwords(tokens)

            # rejoin the tokens so we can re-test the string.
            string_non_stop = ' '.join(tokens_non_stop)
            # we rejoined all tokens with spaces - remove spaces from punctuation
            fixed_commas = re.sub(' (?=[.,;])', '', string_non_stop)
            fixed_dashes = fixed_commas.replace(' - ', '-')
            fixed_parentheses = re.sub('\( (?=\d)', '(', fixed_dashes)

            # fixme: it might be useful to keep compiled regexes somewhere, after all. this is duplicated from below
            name_prefix = r"\b(?:(?:[vV][oa]n(?:\s?t|\s+[dD]e[rn]?|\s+het)?|op(?:\s+het|\s+t)|v\/d|de)\s+|[OoDd]\'|[Mm]a?c)"
            names = name_prefix + r"?([A-Z][a-z,-]+(?:[ +,.;&]|and|et al)*)"
            organisation = r"\b[A-Z]+\s"
            apa_citation_regex = r"(?:%s+|%s),?\(?\d{4}[A-Za-z]?(?:;? ?\d{4}[A-Za-z]?)*" % (names, organisation,)
            match_cit = re.compile(apa_citation_regex)

            # only keep it in our results if it still looks like a citation
            if match_cit.match(fixed_parentheses):
                # adjust the old match object position
                pos = match.position
                match._position = (pos[0] + len(match_str) - len(fixed_parentheses), pos[1])
                refined_matches.append(match)

    return refined_matches


def pop_stopwords(tokens):
    """recursive function to remove stopwords and punctuation from the start of a tokenised sentence"""
    if not tokens:
        return []
    elif tokens[0] not in cap_stopwords and tokens[0].isalpha():
        return tokens
    else:
        return pop_stopwords(tokens[1:])


def parse_numbered_citation(citation):
    """
    (helper function) Get a list of integers for a numbered citation (bracketed or superscript), including enumerating ranges
    :param citation: a single numbered citation string, e.g. '[5-8, 11]'
    :return: a list of integers referred to, e.g. [5, 6, 7, 8, 11]
    """
    stripped = re.sub('\.*<sup>|</sup>|\[|\]', '', citation)

    ints = []
    for s in re.split('[, ]+', stripped):
        try:
            i = int(s)
            ints.append(i)
        except ValueError:
            match_dashes = re.compile('[- –]+')
            if match_dashes.search(s):
                # we have a range; enumerate it
                split = match_dashes.split(s)
                (start, end) = (split.pop(0), split.pop())
                ints.extend(range(int(start), int(end) + 1))
    return ints

def get_citation_numbers(text):
    """ extract a list of citation numbers from text """
    match_num = re.compile('(\[[-\d, –]+\])|(<sup>[-\d, –]+</sup>)')
    res = match_num.finditer(text)

    ints = []
    for r in res:
        ints.append(_parse_numbered_citation(r.group()))

    return ints
