from setuptools import setup, find_packages

setup(
    name = 'Parker',
    version = '0.1',
    packages = find_packages(),
    install_requires = [
        "requests",
        "xmltodict",
        "argparse",
        "numpy",
        #"nltk",
        "colorama",
        "nose",
    ],
    url = 'http://www.peneloperesearch.com/',
    author = 'Steve Eardley',
    author_email = 'steve@cottagelabs.com',
    description = 'Serve Penelope with Python tests',
)
