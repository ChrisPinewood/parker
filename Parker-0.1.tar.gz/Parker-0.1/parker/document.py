"""
Tools to process the document.
"""

import re
from numpy import digitize
from penelope_com import TestResult, tell_penelope, tell_console


def find_in_full_text(regex, text, test_label, report_immediately=True):
    """The basic test - check if a regex matches anywhere in text, and reports the position and pass/fail"""
    result_objects = []
    res = regex.search(text)
    results = regex.finditer(text)
    if res:
        for r in results:
            resultobj = TestResult(test_label, bool(res), position=r.span())
            if report_immediately:
                tell_penelope(resultobj)
            result_objects.append(resultobj)
            # Report the test and the match
            tell_console("'{0}' found '{1}'".format(test_label, r.group()))
    else:
        resultobj = TestResult(test_label, bool(res))
        if report_immediately:
            tell_penelope(resultobj)
        result_objects.append(resultobj)

    return result_objects

# Store the (headings, positions) here so we don't need to run get_sections() too often
sections = None


def get_sections(full_text):
    match_heading = re.compile("^#+( [\w*-]+)+", flags=re.MULTILINE)
    match_italic = re.compile("[*_].+?[*_]")
    match_bold = re.compile("\*\*.+?\*\*|__.+?__")

    match_any_heading = re.compile('^(?:{0}|{1}|{2})'.format(match_heading.pattern, match_bold.pattern, match_italic.pattern), flags=re.MULTILINE)

    all_headings = match_any_heading.finditer(full_text)
    heading_text_list = ['doc_start']
    heading_start_list = [0]               # due to binning with numpy.digitize(), require bins[i-1] < x <= bins[i]
    if all_headings:
        for h in all_headings:
            heading = h.group()
            heading_text_list.append(heading)
            heading_start_list.append(h.start())

    global sections
    sections = (heading_text_list, heading_start_list)

    return heading_text_list, heading_start_list


def in_section(position, text=None, heading_info=None):
    """
    Return the most recent section header for the character index
    :param position: character index
    :return: the section title
    """

    # if not given the heading information, find it now.
    if text and not heading_info:
        (headings, position_bins) = get_sections(text)
    elif heading_info:
        (headings, position_bins) = heading_info
    else:
        return None

    binning_result = digitize([position], position_bins)
    binned_position = binning_result.tolist().pop()
    return headings[binned_position - 1]


def find_in_title_or_section(regex, text, test_label, report_immediately=True):
    """
    Checks if a regex matches a section heading. If not, checks if it matches in section, and returns that section heading.
    :param regex: the compiled regular expression to test for
    :param text: the full text of the document
    :param test_label: the label this test will be reported back as
    :return: a list of TestResults, as defined in penelope_com
    """
    # check for regex in titles
    result = find_in_title(regex, text, test_label, report_immediately=False)

    # check the whole text if not in titles
    if result.passed:
        if report_immediately:
            tell_penelope(result)
        return [result]
    else:
        result_objects = find_in_section(regex, text, test_label, report_immediately=report_immediately)
        return result_objects


def find_in_title(regex, text, test_label, report_immediately=True):
    """
    Checks if a regex matches a section heading.
    :param regex: the compiled regular expression to test for
    :param text: the full text of the document
    :param test_label: the label this test will be reported back as
    :return: a TestResult, as defined in penelope_com, with pass/fail only
    """
    global sections
    if not sections:
        get_sections(text)
    (headings, positions) = sections

    matches = []
    for heading in headings:
        res = regex.search(heading)
        matches.append(bool(res))
        if res:
            # Report which heading matched the regex
            tell_console("'{0}' found in the heading '{1}'".format(res.group(), heading))

    resultobj = TestResult(test_label, any(matches))
    if report_immediately:
        tell_penelope(resultobj)
    return resultobj


def find_in_section(regex, text, test_label, report_immediately=True):
    """
    Checks if a regex matches in any section, and returns that section heading.
    :param regex: the compiled regular expression to test for
    :param text: the full text of the document
    :param test_label: the label this test will be reported back as
    :return: a list of TestResults, as defined in penelope_com
    """
    global sections
    if not sections:
        get_sections(text)
    (headings, positions) = sections

    result_objects = []
    res = regex.search(text)
    results = regex.finditer(text)
    if res:
        for r in results:
            resultobj = TestResult(test_label, bool(res), position=r.span())
            if report_immediately:
                tell_penelope(resultobj)
            result_objects.append(resultobj)
            # Report in which section we have found the matches
            tell_console("'{0}' found in the section '{1}'".format(r.group(), in_section(r.start(), heading_info=(headings, positions))))
    else:
        resultobj = TestResult(test_label, bool(res))
        if report_immediately:
            tell_penelope(resultobj)
        result_objects.append(resultobj)

    return result_objects
