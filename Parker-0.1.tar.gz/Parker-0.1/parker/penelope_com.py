"""
Tools and templates for communicating with Penelope
"""

from __future__ import print_function
from itertools import chain, repeat
import colorama
import sys
import csv

# The filename of the document we're currently working on, default is for files piped in (therefore unnamed)
current_docname = "parker_results"

# Whether to allow parker to print to console using penelope_com.print_to_console()
allow_print = False

# Whether to allow parker to print in colour
colour_print = True

# The format for returning tests to Penelope
TEST_RESULT = {
    'test': None,       # string, required
    'passed': None,     # boolean, required
    'position': {       # optional
        'start': None,   # int, starting character position of result in report
        'end': None      # int, ending character position of result in report
    }
}


def tell_penelope(msg):
    """
    Inform Penelope of the results
    :param thing: What we wish to send
    """
    print(msg, file=sys.stdout)


def warn_penelope(msg):
    """
    Log an error to Penelope
    :param msg: What we wish to send
    """
    print(msg, file=sys.stderr)


def print_to_console(msg):
    """
    Print (in green or monochrome) to console, only when Parker is running with the option { "print" : true }
    :param msg: message to print to console
    """
    if allow_print:
        if colour_print:
            colorama.init()
            print(colorama.Fore.GREEN + msg + colorama.Fore.RESET, file=sys.stdout)
        else:
            print(msg, file=sys.stdout)


def compare_results(text, results):
    """
    Save a CSV file to compare regexes on the same data
    :param text: the text we are using
    :param results: a list of 2 or more result sets (a list of lists)
    """
    # find the maximal result set
    max_res = max(results, key=len)
    # pad the other results to match the length of the maximal set
    results = [list(chain(res, repeat("", len(max_res) - len(res)))) for res in results]

    # filename of csv will be "source doc name-tests we are comparing.csv"
    try:
        tests_run = [r[0]._test for r in results]
    except AttributeError:
        # fixme: something strange is going on - getting strings in some files where TestResult is expected
        """print([(type(r), type(r[0])) for r in results])
        if type(r[0]) is str:
            print(r, r[0])"""
        return
    filename = current_docname + '-' + '-'.join(tests_run) + '.csv'

    # Long filenames will probably upset Windows; truncate if required
    if len(filename) > 260:
        filename = filename[:259]

    with open(filename, 'wb') as csvfile:
        csvwriter = csv.writer(csvfile, delimiter='\t')
        # write the headings
        csvwriter.writerow(tests_run)
        # write the rows
        for i in range(0, len(max_res)):
            csvwriter.writerow([r[i].match_string(text) if type(r[i]) is TestResult else '' for r in results])

def tabulate_results(text, results):
    """
    Tabulate the results of one test across numerous files. Note: this will create a CSV where each row corresponds to
    a different file, so the results are displayed row-wise.
    :param text: the text we are using
    :param results: a result set for the current file
    """
    # Put the result text in a row (the match if TestResult, or the string if string)
    result_row = [r.match_string(text) if type(r) is TestResult else r for r in results]

    # add the filename at the start of the row
    result_row.insert(0, current_docname)

    # If there's no results, log the filename
    if not results:
        with open('parker_no_results.csv', 'ab') as failedfile:
            failedwriter = csv.writer(failedfile, delimiter='\t')
            failedwriter.writerow(result_row)
    else:
        # Otherwise, use the name of a test as the filename
        if type(results[0]) is TestResult:
            filename = results[0]._test + '_results.csv'
        else:
            filename = 'parker_results.csv'

        with open(filename, 'ab') as csvfile:
            csvwriter = csv.writer(csvfile, delimiter='\t')
            csvwriter.writerow(result_row)

def tabulate_parsed_citation_results(citation_lists):
    """
    Tabulate the expanded citation results of one test across numerous files
    :param text: the text we are using
    :param results: a result set for the current file
    """
    # flatten the parsed lists
    row = [item for sublist in citation_lists for item in sublist]

    # add the filename at the start of the row
    row.insert(0, current_docname)

    filename = 'parker_citation_parsed_results.csv'

    with open(filename, 'ab') as csvfile:
        csvwriter = csv.writer(csvfile, delimiter='\t')
        csvwriter.writerow(row)


class TestResult(object):
    """ wrapper object for the result of a test """

    def __init__(self, test, passed, position=None):
        self._test = test
        self._passed = passed
        self._position = position       # (start, end) as in re.matchobj.span()

    def __str__(self):
        from json import dumps
        this_result = TEST_RESULT.copy()
        this_result['test'] = self.test
        this_result['passed'] = self.passed

        # Add the position if present, or remove it
        if self.position:
            (s, e) = self.position
            this_result['position'] = {'start': s, 'end': e}
        else:
            del(this_result['position'])

        return dumps(this_result)

    def print_match(self, text):
        """
        Print the span in text of this result
        :param text: the text this result is for
        """
        if self.position:
            (s, e) = self.position
            print(text[s:e], file=sys.stdout)

    def match_string(self, text):
        """
        return as string the span in text of this result
        :param text: the text this result is for
        :return the matching string
        """
        if self.position:
            (s, e) = self.position
            return text[s:e]
        else:
            return None

    @property
    def test(self):
        return self._test

    @property
    def passed(self):
        return self._passed

    @property
    def position(self):
        return self._position
