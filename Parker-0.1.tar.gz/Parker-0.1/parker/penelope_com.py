"""
Tools and templates for communicating with Penelope
"""

from __future__ import print_function
from itertools import chain, repeat
import colorama
import sys
import csv

# The filename of the document we're currently working on, default is for files piped in (therefore unnamed)
current_docname = "parker_results"

# Whether to allow parker to print to console using penelope_com.tell_console()
allow_print = False

# put json templates for e.g. results here, or as classes so they can be easily replicated

TEST_RESULT = {
    'test': None,       # string, required
    'passed': None,     # boolean, required
    'position': {       # optional
        'start': None,   # int, starting character position of result in report
        'end': None      # int, ending character position of result in report
    }
}


def tell_penelope(msg):
    """
    Inform Penelope of the results
    :param thing: What we wish to send
    """
    pass
    print(msg, file=sys.stdout)


def warn_penelope(msg):
    """
    Log an error to Penelope
    :param msg: What we wish to send
    """
    print(msg, file=sys.stderr)


def tell_console(msg):
    """
    Print (in green) to console, only when Parker is running with the option { "print' : true }
    :param msg: message to print to console
    """
    colorama.init()
    global allow_print
    if allow_print:
        print(colorama.Fore.GREEN + msg + colorama.Fore.RESET, file=sys.stdout)

def compare_results(text, results):
    """
    Save a CSV file to compare regexes
    :param text: the text we are using
    :param results: a list of 2 or more result sets (a list of lists)
    """
    # find the maximal result set
    max_res = max(results, key=len)
    # pad the other results to match the length of the maximal set
    results = [list(chain(res, repeat("", len(max_res) - len(res)))) for res in results]

    # filename of csv will be "source doc name-tests we are comparing.csv"
    tests_run = [r[0]._test for r in results]
    filename = current_docname + '-' + '-'.join(tests_run) + '.csv'

    # Long filenames will probably upset Windows; truncate if required
    if len(filename) > 260:
        filename = filename[:259]

    with open(filename, 'wb') as csvfile:
        csvwriter = csv.writer(csvfile, delimiter='\t')
        # write the headings
        csvwriter.writerow(tests_run)
        # write the rows
        for i in range(0, len(max_res)):
            csvwriter.writerow([r[i].match_string(text) if type(r[i]) is TestResult else '' for r in results])


class TestResult(object):
    def __init__(self, test, passed, position=None):
        self._test = test
        self._passed = passed
        self._position = position       # (start, end) as in re.matchobj.span()

    def __str__(self):
        from json import dumps
        this_result = TEST_RESULT.copy()
        this_result['test'] = self.test
        this_result['passed'] = self.passed

        # Add the position if present, or remove it
        if self.position:
            (s, e) = self.position
            this_result['position'] = {'start': s, 'end': e}
        else:
            del(this_result['position'])

        return dumps(this_result)

    def print_match(self, text):
        """
        Print the span in text of this result
        :param text: the text this result is for
        """
        if self.position:
            (s, e) = self.position
            print(text[s:e], file=sys.stdout)

    def match_string(self, text):
        """
        Print the span in text of this result
        :param text: the text this result is for
        """
        if self.position:
            (s, e) = self.position
            return text[s:e]
        else:
            return None

    @property
    def test(self):
        return self._test

    @property
    def passed(self):
        return self._passed

    @property
    def position(self):
        return self._position
