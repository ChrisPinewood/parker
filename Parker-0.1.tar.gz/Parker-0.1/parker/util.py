class JSONDictWriter(object):
    def __init__(self, path):
        self.f = open(path, "wb")
        self.f.write("{")
        self.first = True

    def write(self, serialised_json_object):
        if self.first:
            self.first = False
        else:
            self.f.write(",")
        self.f.write(serialised_json_object[1:-1])

    def close(self):
        self.f.write("}")
        self.f.close()
