"""
Run one or more test from the collection
"""
from tests import *

if __name__ == '__main__':
    # If this file is run, demonstrate the tests with an example.
    print "Demo run\n"

    text = "This text will match because it contains 'hello, world' including the comma. It also matches hello world," \
           " so there will be two matches in the text."
    print text
    example_tests.hello_world(text)
    print
    text2 = "This text won't match because it only says hello."
    print text2
    example_tests.hello_world(text2)
