"""
Example test written in Parker
"""
from parker.penelope_com import TestResult, tell_penelope
import re


def hello_world(text):
    test_label = 'hello_world'
    match_hello = re.compile('hello,* world')

    # Need to both search and finditer because there isn't a good way to check if iterator is empty
    res = match_hello.search(text)
    results = match_hello.finditer(text)

    if res:
        for r in results:
            tell_penelope(TestResult(test_label, bool(res), position=r.span()))
    else:
        tell_penelope(TestResult(test_label, bool(res)))
