#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Tests for a variety of citation styles
"""
from parker.document import find_in_full_text
from parker.penelope_com import TestResult, tell_penelope, tell_console, compare_results
from references import get_reference_numbers
import re

def check_citation_style(text):
    res_apa = find_apa_citations_simple(text, False)
    res_num = find_numbered_citations(text, False)
    res_sup = find_superscript_citations(text, False)

    res_best = max(res_apa, res_num, res_sup, key=len)
    if res_best == res_apa:
        tell_console("APA style")
        rs0 = find_apa_citations_simple(text)
        rs1 = find_apa_citations_name_prefix(text)
        compare_results(text, [rs0, rs1])
    elif res_best == res_num:
        tell_console("numerical style")
    elif res_best == res_sup:
        tell_console("superscript style")

def find_apa_citations_strict(text):
    #paren = '\([^)]+\)'
    name = "(?:[a-z'-]+)"
    conj = '(?:,| &| and)'
    names = "{0}+(({1} {0})| et al[.]*)*".format(name, conj)
    date = "\d{4}[A-Za-z]?"
    citation = "{0},* {1}([; ]+{1})*".format(names, date)
    multi_citation = '\({0}(; {0})*\)'.format(citation)

    match_cit = re.compile(multi_citation, flags=re.IGNORECASE)
    return find_in_full_text(match_cit, text, 'find_apa_citations_strict')


def find_apa_citations_name_prefix(text):
    name_prefix = r"\b(([vV][oa]n(\s+t|\s+[dD]e[rn]?|\s+het)?|op(\s+het|\s+t)|v\/d|de)\s+|[OoDd]\'|[Mm]a?c)"
    names = name_prefix + r"?([A-Z][a-z,\-]+([ +\,\.\;\&]*| and ))"
    organisation = r"\b[A-Z]+\b"
    apa_citation_regex = r"(%s+|%s)[(et al)\W]*\d{4}[A-Za-z]?([; ]+\d{4}[A-Za-z]?)*" % (names, organisation,)
    match_cit = re.compile(apa_citation_regex)
    return find_in_full_text(match_cit, text, 'find_apa_citations_name_prefix')


def find_apa_citations_simple(text, report_immediately=True):
    match_paren = re.compile('\([^()]+?\s\d{4}[A-Za-z]?\)')
    return find_in_full_text(match_paren, text, 'find_apa_citations_simple', report_immediately)


def find_numbered_citations(text, report_immediately=True):
    match_num = re.compile('\[[-\d, –]+\]')
    return find_in_full_text(match_num, text, 'find_numbered_citations', report_immediately)


def find_superscript_citations(text, report_immediately=True):
    #match_sup = re.compile('\.<sup>[-\d, –]+</sup>') # removed . because they can be in sentences
    match_sup = re.compile('<sup>[-\d, –]+</sup>') # this might collect formulae too, now
    return find_in_full_text(match_sup, text, 'find_superscript_citations', report_immediately)


def verify_num_citation_seq(text):
    """
    Check that numbered citations are complete.
    """

    match_num = re.compile('(\[[-\d, –]+\])|(\.<sup>[-\d, –]+</sup>)')
    res = match_num.finditer(text)

    all_citation_ints = []
    set_citation_ints = []           # we can't use an actual set because ordering is useful here

    for r in res:
        ints_in_citations = _parse_numbered_citation(r.group())
        all_citation_ints.extend(ints_in_citations)
        [set_citation_ints.append(i) for i in ints_in_citations if i not in set_citation_ints]

    sorted_set = sorted(set_citation_ints)
    results = []

    # Check if we see the citations in the right order
    if sorted_set != set_citation_ints:
        result = TestResult('verify_num_citation_seq:numerical_order', False)
        tell_penelope(result)
        results.append(result)
        tell_console("Citation numerical order: (a) set of citations / (b) sorted set of citations")
        tell_console('(a) ' + str(set_citation_ints))
        tell_console('(b) ' + str(sorted_set))

    # Check there are no missing citations
    if range(sorted_set[0], sorted_set[-1] + 1) != sorted_set:
        result = TestResult('verify_num_citation_seq:full_sequence', False)
        tell_penelope(result)
        results.append(result)
        tell_console("Full citation sequence: (a) set of citations / (b) range from min to max")
        tell_console('(a) ' + str(sorted_set))
        tell_console('(b) ' + str(range(sorted_set[0], sorted_set[-1] + 1)))

    # Check all citations are present in references & vice versa (we can use sets here; ordering was checked before)
    ref_nums = set(get_reference_numbers(text))
    if ref_nums.symmetric_difference(set(all_citation_ints)):
        result = TestResult('verify_num_citation_seq:citation_reference_mismatch', False)
        tell_penelope(result)
        results.append(result)
        tell_console("Citations vs references (a) set of citations / (b) set of reference numbers")
        tell_console('(a) ' + str(list(set(all_citation_ints))))
        tell_console('(b) ' + str(list(ref_nums)))

    if results:
        return results
    else:
        result = TestResult('verify_num_citation_seq', True)
        tell_penelope(result)
        return [result]


def _parse_numbered_citation(citation):
    """
    Get a list of integers for a numbered citation (bracketed or superscript), including enumerating ranges
    :param citation: a single numbered citation string, e.g. '[5-8, 11]'
    :return: a list of integers referred to, e.g. [5, 6, 7, 8, 11]
    """
    stripped = re.sub('\.<sup>|</sup>|\[|\]', '', citation)

    ints = []
    for s in re.split('[, ]+', stripped):
        try:
            i = int(s)
            ints.append(i)
        except ValueError:
            match_dashes = re.compile('[- –]+')
            if match_dashes.search(s):
                # we have a range; enumerate it
                split = match_dashes.split(s)
                (start, end) = (split.pop(0), split.pop())
                ints.extend(range(int(start), int(end) + 1))
    return ints
