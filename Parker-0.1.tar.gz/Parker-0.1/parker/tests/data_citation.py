#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Tests for checking data citations
"""
from parker.penelope_com import warn_penelope
from parker.document import find_in_title_or_section, find_in_full_text
import re
import os
import json

try:
    data_file = open(os.path.abspath(os.path.dirname(__file__) + '/../data/re3data.json'), 'rb')
    repo_dict = json.load(data_file)
except IOError:
    warn_penelope("Couldn't read repository data file.")


def find_data_citations(text):
    repo_names = repo_dict.keys()
    patterns = [r'\b%s\b' % re.escape(key.strip()) for key in repo_names]

    match_repos = re.compile('|'.join(patterns), flags=re.IGNORECASE)
    return find_in_full_text(match_repos, text, 'find_data_citations')


def find_uri(text):
    match_doi = r'\b10\.[0-9]+\S+\b'
    # URL regex from https://gist.github.com/gruber/249502
    match_url = r"(?i)\b((?:[a-z][\w-]+:(?:/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'\".,<>?«»“”‘’]))"
    match_uri = re.compile('{0}|{1}'.format(match_doi, match_url))
    return find_in_full_text(match_uri, text, 'find_uri')


def find_data_access_statement(text):
    match_das = re.compile(r'\bdata.+?statement\b', flags=re.IGNORECASE)
    return find_in_title_or_section(match_das, text, 'find_data_access_statement')
