#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Tests on a document's titles"""

from parker.document import find_in_title_or_section
from parker.penelope_com import tell_console
import re


def find_funding(text):
    match_funding = re.compile(r'\bfunding\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_funding, text, 'find_funding')


def find_competing_interests(text):
    match_competing_interests = re.compile(r'\bcompeting interests\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_competing_interests, text, 'find_competing_interests')


def find_ethics(text):
    match_ethics = re.compile(r'\bethics\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_ethics, text, 'find_ethics')


def title_lengths(text):
    match_md_heading = re.compile("^#+( [\w*-]+)+", flags=re.MULTILINE)
    match_md_italic = re.compile("[*_].+?[*_]")
    match_md_bold = re.compile("\*\*.+?\*\*|__.+?__")
    match_heading_shortness = re.compile("^[-\w\d '–]+$", flags=re.MULTILINE)

    match_any_heading = re.compile('^(?:{0}|{1}|{2}|{3})'.format(match_md_heading.pattern, match_md_bold.pattern, match_md_italic.pattern, match_heading_shortness.pattern), flags=re.MULTILINE)
    match_markup = re.compile(r'\s*[#*_.:]+\s*')

    all_headings = match_any_heading.finditer(text)

    n_main = n_sub = n_all = 0

    tell_console('length\ttype\theading')
    for heading in all_headings:
        n_all += 1

        # Use max-length string in split text (other entries should be 0-length for each markup match)
        heading_text_only = max(match_markup.split(heading.group()), key=len)
        if match_md_bold.search(heading.group()) or match_md_italic.search(heading.group()):
            n_sub += 1
            tell_console("{1}\tsub\t'{0}'".format(heading_text_only, len(heading_text_only)))
        else:
            n_main += 1
            tell_console("{1}\tmain\t'{0}'".format(heading_text_only, len(heading_text_only)))

    tell_console('\n{0} heading(s) found; {1} main heading(s) and {2} subheading(s).'.format(n_all, n_main, n_sub))
