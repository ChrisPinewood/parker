#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Tests on a document's titles"""

from parker.document import find_in_title_or_section, strip_markup, find_in_full_text
from parker.penelope_com import print_to_console, compare_results
import re

### MAIN TESTS FOR PENELOPE

def find_funding(text, report_immediately=True):
    """ find the funding statement in a doc """
    match_funding = re.compile(r'\bfunding\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_funding, text, 'find_funding', report_immediately)


def find_competing_interests(text, report_immediately=True):
    """ find the competing interests section in a doc """
    match_competing_interests = re.compile(r'\bcompeting interests\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_competing_interests, text, 'find_competing_interests', report_immediately)


def find_ethics(text, report_immediately=True):
    """ find the ethics statement in a doc """
    match_ethics = re.compile(r'\bethics\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_ethics, text, 'find_ethics', report_immediately)

### TESTS / TOOLS FOR CONSOLE

def compare_title_regexes(text):
    """ (console only) Comparing regexes to improve title discovery"""

    #todo: a work in progress - attempting to change the '.+?' with something that's just non-whitespace (while allowing spaces)
    match_md_heading = re.compile(r"^#+[^\t\n\r\f\v]+?$")
    match_md_italic = re.compile(r"^[*_][^\t\n\r\f\v]+?[*_]$")
    match_md_bold = re.compile(r"^\*\*[^\t\n\r\f\v]+?\*\*$|^__[^\t\n\r\f\v]+?__$")
    match_heading_shortness = re.compile(r"^[^\t\n\r\f\v]+$")

    match_any_heading_new = re.compile(r'(?:{0}|{1}|{2}|{3})'.format(match_md_heading.pattern, match_md_bold.pattern, match_md_italic.pattern, match_heading_shortness.pattern), flags=re.MULTILINE)
    res = find_in_full_text(match_any_heading_new, text, 'match_any_heading_new', False)

    match_md_heading1 = re.compile("^#+.+?$")
    match_md_italic1 = re.compile("^[*_].+?[*_]$")
    match_md_bold1 = re.compile("^\*\*.+?\*\*$|^__.+?__$")
    match_heading_shortness1 = re.compile("^[-\w\d :?!;'–]+$")

    match_any_heading_old = re.compile('(?:{0}|{1}|{2}|{3})'.format(match_md_heading1.pattern, match_md_bold1.pattern, match_md_italic1.pattern, match_heading_shortness1.pattern), flags=re.MULTILINE)
    res1 = find_in_full_text(match_any_heading_old, text, 'match_any_heading_old', False)

    compare_results(text, [res, res1])

def title_lengths(text):
    """ (console only) provide a report on the titles and lengths in a document """
    match_md_heading = re.compile("^#+.+?$")
    match_md_italic = re.compile("^[*_].+?[*_]$")
    match_md_bold = re.compile("^\*\*.+?\*\*$|^__.+?__$")
    match_heading_shortness = re.compile("^[-\w\d :?!;'–]+$")

    match_any_heading = re.compile('(?:{0}|{1}|{2}|{3})'.format(match_md_heading.pattern, match_md_bold.pattern, match_md_italic.pattern, match_heading_shortness.pattern), flags=re.MULTILINE)
    all_headings = match_any_heading.finditer(text)

    n_main = n_sub = n_all = 0

    print_to_console('length\ttype\theading')
    for heading in all_headings:
        n_all += 1

        # Use max-length string in split text (other entries should be 0-length for each markup match)
        heading_text_only = strip_markup(heading.group())
        if match_md_bold.search(heading.group()) or match_md_italic.search(heading.group()):
            n_sub += 1
            print_to_console("{1}\tsub\t'{0}'".format(heading_text_only, len(heading_text_only)))
        else:
            n_main += 1
            print_to_console("{1}\tmain\t'{0}'".format(heading_text_only, len(heading_text_only)))

    print_to_console('\n{0} heading(s) found; {1} main heading(s) and {2} subheading(s).'.format(n_all, n_main, n_sub))
