"""
Tests related to references in a document
"""

import re
from parker.document import find_in_full_text
from parker.penelope_com import tell_penelope, TestResult, tell_console

def find_all_references(text):
    res = []
    res.extend(find_num_references(text, False))
    res.extend(find_alpha_references(text, False))
    return res


def find_num_references(text, report_immediately=True):
    match_num_ref = re.compile('^[#*_]*\d+\. *.*?$', flags=re.MULTILINE)
    return find_in_full_text(match_num_ref, text, 'find_num_references', report_immediately)


def find_alpha_references(text, report_immediately=True):
    names = "(?:[.a-zA-Z' ,-]+)"
    match_alpha_ref = re.compile("^%s\(\d{4}\).*(?=\s)$" % names, flags=re.MULTILINE)
    return find_in_full_text(match_alpha_ref, text, 'find_alpha_references', report_immediately)


def get_reference_numbers(text):
    match_ref = re.compile(r'^[#*_]*\d+\. *.*?$', flags=re.MULTILINE)

    ints = []
    res = match_ref.finditer(text)
    for r in res:
        # find the first number group (the reference's number)
        ref = r.group()
        num = re.search('\d+', ref).group()
        ints.append(int(num))

    return ints


def verify_num_reference_seq(text):
    """
    Check the reference numerical sequence is correct
    :param text: the full text, or reference section
    """

    ints = get_reference_numbers(text)
    sorted_ints = sorted(ints)
    results = []

    # Check if we see the references in the right order
    if sorted_ints != ints:
        result = TestResult('verify_num_reference_seq:numerical_order', False)
        tell_penelope(result)
        results.append(result)
        tell_console("Reference numerical order: (a) reference numbers / (b) sorted reference numbers")
        tell_console('(a) ' + str(ints))
        tell_console('(b) ' + str(sorted_ints))

    # Check there are no missing references
    if range(sorted_ints[0], sorted_ints[-1] + 1) != sorted_ints:
        result = TestResult('verify_num_reference_seq:full_sequence', False)
        tell_penelope(result)
        results.append(result)
        tell_console("Full reference sequence: (a) reference numbers / (b) range from min to max")
        tell_console('(a) ' + str(sorted_ints))
        tell_console('(b) ' + str(range(sorted_ints[0], sorted_ints[-1] + 1)))

    # Check there are no repeated reference numbers
    if len(ints) != len(set(ints)):
        result = TestResult('verify_num_reference_seq:duplicate_numbers', False)
        tell_penelope(result)
        results.append(result)
        tell_console("Duplicate reference numbers:\n" + str(ints))

    if results:
        return results
    else:
        result = TestResult('verify_num_reference_seq', True)
        tell_penelope(result)
        return [result]
