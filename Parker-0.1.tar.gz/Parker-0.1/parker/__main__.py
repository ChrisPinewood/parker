"""
Entry point to the Parker module. Handles options and calls tests to run.
"""

import tests
import json
import argparse
import sys
import os
import penelope_com
from glob import glob


## Some functions to run tests ##
def apply_options(json_options):
    try:
        options = json.loads(json_options)
    except ValueError:
        penelope_com.warn_penelope("Error reading options. Check they're valid JSON and try again.")
        sys.exit(1)

    # Get the print to console option
    try:
        penelope_com.allow_print = options['print']
    except KeyError:
        penelope_com.allow_print = False

    # Get the specified tests
    tests_to_run = []
    try:
        for test in options['tests']:
            try:
                test_func = getattr(tests, test)
                tests_to_run.append(test_func)
            except AttributeError as e:
                penelope_com.warn_penelope("Error: no test found called {0}".format(str(e).split().pop()))
    except KeyError:
        # no tests specified, we'll do the default run
        pass
    return tests_to_run


def default_run(full_text):
    # Specify all tests to run here.
    #rs = tests.title_lengths(full_text)

    #rs = tests.verify_num_citation_seq(full_text)
    #rs = tests.verify_num_reference_seq(full_text)

    rs = tests.check_citation_style(full_text)
    #rs = tests.find_all_references(full_text)


def run_tests(fileobj, tests_to_run):
    """run Parker tests on an incoming file object"""
    with fileobj:
        try:
            full_text = fileobj.read()
        except KeyboardInterrupt:
            parser.print_help()
            sys.exit(1)

    # run the tests specified, or the default set of tests
    if tests_to_run:
        [t(full_text) for t in tests_to_run]
        sys.exit(0)
    else:
        default_run(full_text)

## Argument parser to run this module ##
parser = argparse.ArgumentParser(prog='parker',
                                 description='Parker, runs tests from Penelope. Pipe the input text via stdin. '
                                             'If neither file nor pipe present, will expect typed text followed by ^D')

parser.add_argument('-o', '--options', help='Options for Parker, as a JSON object')
parser.add_argument('-f', '--file', help='Run on a file instead of stdin')
parser.add_argument('-d', '--dir', help='Run on all markdown files in a directory')

args = parser.parse_args()

# Specify some options for Parker
if args.options:
    test_options = apply_options(str(args.options))
else:
    test_options = None

if args.file and args.dir:
    print "Please specify either a file OR a directory as inputs, not both."
    sys.exit(1)

# Get the input for tests, and run them
if args.file and not args.dir:
    # a single file
    f = open(args.file, 'r')
    run_tests(f, test_options)

elif args.dir and not args.file:
    # run on all files in a directory
    directory = args.dir
    if os.path.isabs(directory):
        directory_path = directory
    else:
        directory_path = os.path.abspath(directory)

    for filepath in glob(os.path.join(directory_path, '*.md')):
        filename = os.path.basename(filepath)
        penelope_com.current_docname = filename
        penelope_com.tell_console('\n***\n\n{0}'.format(filename))
        run_tests(open(filepath, 'r'), test_options)

else:
    # take piped or typed input
    f = sys.stdin
    run_tests(f, test_options)
