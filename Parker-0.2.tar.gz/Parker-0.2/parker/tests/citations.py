#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Tests for a variety of citation styles.
Note: this file is explicitly encoded utf-8 because of the specific use of dash/hyphen symbols : - –
"""

from parker.document import find_in_full_text
from parker.penelope_com import TestResult, tell_penelope, warn_penelope, print_to_console
from nltk.tokenize.regexp import wordpunct_tokenize
from parker.data import stopwords
from parker.helpers.references import get_reference_numbers
from parker.helpers.citations import *
from copy import deepcopy
import re

# Capitalise each of our stopwords, append our list of days and months.
cap_stopwords = [w.capitalize() for w in stopwords.stop] + stopwords.days_and_months

# Dict informing which tests are dependent on a certain citation style
cit_styles = {'apa': {'verify': None},
              'num': {'verify': 'verify_num_citation_seq'},
              'sup': {'verify': 'verify_num_citation_seq'}
              }


### MAIN TESTS FOR PENELOPE

def find_citations(text, report_immediately=True):
    """ The main function for finding citations - returns the results only of the most counted style """
    doc_style, citation_res = check_citation_style(text)
    if report_immediately:
        for r in citation_res:
            tell_penelope(r)
    return citation_res

def find_apa_citations(text):
    """ The main function we use to identify APA-style citations"""

    # use the name prefix method to get our citations
    raw_res = find_apa_citations_name_prefix(text, False)

    # filter out false positives from our citation list
    filtered_res = filter_apa_citation_matches(deepcopy(raw_res), text)

    return filtered_res


def verify_citation_seq(text, report_immediately=True):
    """The main function we run to check for citation sequence - checks which verification to run"""
    doc_style, citation_res = check_citation_style(text)
    verification_test = cit_styles[doc_style]['verify']

    if verification_test:
        # run the verification test we found
        globals()[verification_test](text, report_immediately)

def verify_citation_in_references(text, report_immediately=True):
    """ The main functions we runt to check that a citation found in the text exists in the references section """
    match_num = re.compile('(\[[-\d, –]+\])|(<sup>[-\d, –]+</sup>)')
    res = match_num.finditer(text)

    all_citation_ints = []
    set_citation_ints = []           # we can't use an actual set because ordering is useful here
    results = []

    ref_nums = set(get_reference_numbers(text))

    for r in res:
        (s, e) = r.span()
        warn_penelope(r.group())
        ints_in_citations = set(parse_numbered_citation(r.group()))
        missing_citations = ints_in_citations.difference(ref_nums)
        if missing_citations:
            warn_penelope('(' + str(s) + ', ' + str(e) + ')')
            result = TestResult(test='verify_citation_in_references', passed=False, position=(s, e))
            warn_penelope(str(result))
            results.append(result)
            if report_immediately:
                tell_penelope(result)

    if results:
        return results
    else:
        result = TestResult('verify_citation_in_references', True)
        if report_immediately:
            tell_penelope(result)
        return [result]

### SUPPLEMENTARY TESTS

def find_apa_citations_name_prefix(text, report_immediately=True):
    """ The favoured method for finding citations. Checks for a name followed by a date. Requires filtering for good results."""
    name_prefix = r"\b(?:(?:[vV][oa]n(?:\s?t|\s+[dD]e[rn]?|\s+het)?|op(?:\s+het|\s+t)|v\/d|de)\s+|[OoDd]\'|[Mm]a?c)"
    names = name_prefix + r"?([A-Z][a-z,-]+(?:[ +,.;&]|and|et al)*)"
    organisation = r"\b[A-Z]+\s"
    apa_citation_regex = r"(?:%s+|%s),?\(?\d{4}[A-Za-z]?(?:;? ?\d{4}[A-Za-z]?)*" % (names, organisation,)
    match_cit = re.compile(apa_citation_regex)
    return find_in_full_text(match_cit, text, 'find_apa_citations_name_prefix', report_immediately)


def find_numbered_citations(text, report_immediately=True):
    """ Find numbers or ranges of numbers within brackets. """
    match_num = re.compile('\[[-\d, –]+\]')
    return find_in_full_text(match_num, text, 'find_numbered_citations', report_immediately)


def find_superscript_citations(text, report_immediately=True):
    """ Numbers or ranges within superscript tags. Tends to also pick up formulae """
    match_sup = re.compile('<sup>[-\d, –]+</sup>')
    return find_in_full_text(match_sup, text, 'find_superscript_citations', report_immediately)


def find_apa_citations_strict(text, report_immediately=True):
    """ A (deprecated) strict check for APA citations """
    #paren = '\([^)]+\)'
    name = r"(?:[a-z'-]+)"
    conj = r"(?:,|&|and)"
    names = r"{0}(?:(?:\s?{1}\s{0})| et al\.*)*".format(name, conj)
    date = r"\d{4}[a-z]?"
    citation = r"{0},? {1}(?:[; ]+{1})*".format(names, date)
    multi_citation = r"\({0}(; {0})*\)".format(citation)

    match_cit = re.compile(multi_citation, flags=re.IGNORECASE)
    return find_in_full_text(match_cit, text, 'find_apa_citations_strict', report_immediately)


def find_apa_citations_simple(text, report_immediately=True):
    """ A (deprecated) very simple and naive method for finding citations - a date in parentheses """
    match_paren = re.compile('\([^()]+?\s\d{4}[A-Za-z]?\)')
    return find_in_full_text(match_paren, text, 'find_apa_citations_simple', report_immediately)


def verify_num_citation_seq(text):
    """
    Check that numbered citations are correct. Three tests:
    * ensure the citations appear in the correct order
    * ensure there are no numbers missing from sequence
    * check the citations are fully represented in reference section, and vice versa.
    """

    match_num = re.compile('(\[[-\d, –]+\])|(<sup>[-\d, –]+</sup>)')
    res = match_num.finditer(text)

    all_citation_ints = []
    set_citation_ints = []           # we can't use an actual set because ordering is useful here

    for r in res:
        ints_in_citations = parse_numbered_citation(r.group())
        all_citation_ints.extend(ints_in_citations)
        [set_citation_ints.append(i) for i in ints_in_citations if i not in set_citation_ints]

    sorted_set = sorted(set_citation_ints)
    results = []

    # Check if we see the citations in the right order
    if sorted_set != set_citation_ints:
        result = TestResult('verify_num_citation_seq:numerical_order', False)
        tell_penelope(result)
        results.append(result)
        print_to_console("Citation numerical order: (a) set of citations / (b) sorted set of citations")
        print_to_console('(a) ' + str(set_citation_ints))
        print_to_console('(b) ' + str(sorted_set))

    # Check there are no missing citations
    if range(sorted_set[0], sorted_set[-1] + 1) != sorted_set:
        result = TestResult('verify_num_citation_seq:full_sequence', False)
        tell_penelope(result)
        results.append(result)
        print_to_console("Full citation sequence: (a) set of citations / (b) range from min to max")
        print_to_console('(a) ' + str(sorted_set))
        print_to_console('(b) ' + str(range(sorted_set[0], sorted_set[-1] + 1)))

    # Check all citations are present in references & vice versa (we can use sets here; ordering was checked before)
    ref_nums = set(get_reference_numbers(text))
    if ref_nums.symmetric_difference(set(all_citation_ints)):
        result = TestResult('verify_num_citation_seq:citation_reference_mismatch', False)
        tell_penelope(result)
        results.append(result)
        print_to_console("Citations vs references (a) set of citations / (b) set of reference numbers")
        print_to_console('(a) ' + str(list(set(all_citation_ints))))
        print_to_console('(b) ' + str(list(ref_nums)))

    # We only have results if the checks failed; report these or return a successful result
    if results:
        return results
    else:
        result = TestResult('verify_num_citation_seq', True)
        tell_penelope(result)
        return [result]
