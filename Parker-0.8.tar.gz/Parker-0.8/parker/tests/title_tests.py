#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Tests on a document's titles"""

from parker.document import find_in_title_or_section, strip_markup, find_in_full_text
from parker.penelope_com import print_to_console, compare_results
import re

### MAIN TESTS FOR PENELOPE

def find_abstract(text, report_immediately=True):
    """ find the abstract in a doc """
    match_abstract = re.compile(r'\babstract\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_abstract, text, 'find_abstract', report_immediately)

def find_acknowledgements(text, report_immediately=True):
    """ find the acknowledgements in a doc """
    match_acknowledgements = re.compile(r'\backnowledgements\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_acknowledgements, text, 'find_acknowledgements', report_immediately)

def find_competing_interests(text, report_immediately=True):
    """ find the competing interests section in a doc """
    match_competing_interests = re.compile(r'\bcompeting interests\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_competing_interests, text, 'find_competing_interests', report_immediately)

def find_data_access_statement(text, report_immediately=True):
    """ find the data access statement in a doc """
    match_data_access_statement = re.compile(r'\bdata acces\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_data_access_statement, text, 'find_data_access_statement', report_immediately)

def find_discussion(text, report_immediately=True):
    """ find the discussion in a doc """
    match_discussion = re.compile(r'\bdiscussion\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_discussion, text, 'find_discussion', report_immediately)

def find_introduction(text, report_immediately=True):
    """ find the introduction in a doc """
    match_introduction = re.compile(r'\bintroduction\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_introduction, text, 'find_introduction', report_immediately)

def find_methods(text, report_immediately=True):
    """ find the methods in a doc """
    match_methods = re.compile(r'\bmethods\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_methods, text, 'find_methods', report_immediately)

def find_references(text, report_immediately=True):
    """ find the references in a doc """
    match_references = re.compile(r'\breferences\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_references, text, 'find_references', report_immediately)

def find_results(text, report_immediately=True):
    """ find the results in a doc """
    match_results = re.compile(r'\bresults\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_results, text, 'find_results', report_immediately)


def find_funding(text, report_immediately=True):
    """ find the funding statement in a doc """
    match_funding = re.compile(r'\bfunding\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_funding, text, 'find_funding', report_immediately)

def find_ethics(text, report_immediately=True):
    """ find the ethics statement in a doc """
    match_ethics = re.compile(r'\bethics\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_ethics, text, 'find_ethics', report_immediately)

### TESTS / TOOLS FOR CONSOLE

def compare_title_regexes(text):
    """ (console only) Comparing regexes to improve title discovery"""

    #todo: a work in progress - attempting to change the '.+?' with something that's just non-whitespace (while allowing spaces)
    match_md_heading = re.compile(r"^#+[^\t\n\r\f\v]+?$")
    match_md_italic = re.compile(r"^[*_][^\t\n\r\f\v]+?[*_]$")
    match_md_bold = re.compile(r"^\*\*[^\t\n\r\f\v]+?\*\*$|^__[^\t\n\r\f\v]+?__$")
    match_heading_shortness = re.compile(r"^[^\t\n\r\f\v]+$")

    match_any_heading_new = re.compile(r'(?:{0}|{1}|{2}|{3})'.format(match_md_heading.pattern, match_md_bold.pattern, match_md_italic.pattern, match_heading_shortness.pattern), flags=re.MULTILINE)
    res = find_in_full_text(match_any_heading_new, text, 'match_any_heading_new', False)

    match_md_heading1 = re.compile("^#+.+?$")
    match_md_italic1 = re.compile("^[*_]\n?.+?[*_]$")
    match_md_bold1 = re.compile("^\*\*\n?.+?\*\*$|^__\n?.+?__$")
    match_heading_shortness1 = re.compile("^[-\w\d :?!;'–]+$")

    match_any_heading_old = re.compile('(?:{0}|{1}|{2}|{3})'.format(match_md_heading1.pattern, match_md_bold1.pattern, match_md_italic1.pattern, match_heading_shortness1.pattern), flags=re.MULTILINE)
    res1 = find_in_full_text(match_any_heading_old, text, 'match_any_heading_old', False)

    compare_results(text, [res, res1])

def title_lengths(text):
    """ (console only) provide a report on the titles and lengths in a document """
    match_md_heading = re.compile("^#+.+?$")
    match_md_italic = re.compile("^[*_]\n?.+?[*_]$")
    match_md_bold = re.compile("^\*\*\n?.+?\*\*$|^__\n?.+?__$")
    match_heading_shortness = re.compile("^[-\w\d :?!;'–]+$")

    match_any_heading = re.compile('(?:{0}|{1}|{2}|{3})'.format(match_md_heading.pattern, match_md_bold.pattern, match_md_italic.pattern, match_heading_shortness.pattern), flags=re.MULTILINE)
    all_headings = match_any_heading.finditer(text)

    n_main = n_sub = n_all = 0

    print_to_console('length\ttype\theading')
    for heading in all_headings:
        n_all += 1

        # Use max-length string in split text (other entries should be 0-length for each markup match)
        heading_text_only = strip_markup(heading.group())
        if match_md_bold.search(heading.group()) or match_md_italic.search(heading.group()):
            n_sub += 1
            print_to_console(u"{1}\tsub\t'{0}'".format(heading_text_only, len(heading_text_only)))
        else:
            n_main += 1
            print_to_console(u"{1}\tmain\t'{0}'".format(heading_text_only, len(heading_text_only)))

    print_to_console(u'\n{0} heading(s) found; {1} main heading(s) and {2} subheading(s).'.format(n_all, n_main, n_sub))
