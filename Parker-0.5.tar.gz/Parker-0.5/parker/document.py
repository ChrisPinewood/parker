#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Tools to process the document. These are mainly workflow for running regexes on different parts of the document.
"""

import re
from numpy import digitize
from penelope_com import TestResult, tell_penelope, print_to_console
from nltk import metrics, stem, tokenize


def find_in_full_text(regex, text, test_label, report_immediately=True):
    """ The basic test - check if a regex matches anywhere in text, and reports the position and pass/fail
    :param regex: a regular expression object
    :param text: the text we are searching
    :param test_label: what to call the test - the label this test will be reported back as
    :param report_immediately: Whether to send results to Penelope as they come in
    :return: a list of TestResults, as defined in penelope_com
    """
    result_objects = []
    res = regex.search(text)
    results = regex.finditer(text)
    if res:
        for r in results:
            resultobj = TestResult(test_label, bool(res), position=r.span())
            if report_immediately:
                tell_penelope(resultobj)
            result_objects.append(resultobj)
            # Report the test and the match
            print_to_console(u"'{0}' found '{1}'".format(test_label, r.group()))
    else:
        resultobj = TestResult(test_label, bool(res))
        if report_immediately:
            tell_penelope(resultobj)
        result_objects.append(resultobj)

    return result_objects

def find_in_doc_slice(regex, full_text, start_section, end_section, test_label, report_immediately=True):
    """
    Run a text on a span of test within the document
    :param regex: the compiled regular expression to test for
    :param full_text: the full text of the document
    :param start_section: the starting index (string title or int index from section list)
    :param end_section: the end index (string title or int index from section list)
    :param test_label: the label this test will be reported back as
    :return: a list of TestResults, as defined in penelope_com
    """
    result_objects = []

    # Use the section indexes or titles to get the text span
    (headings, positions) = get_sections(full_text)

    text_start_index = 0
    if type(start_section) is str or type(start_section) is unicode:
        text_start_index = positions[headings.index(start_section)]
    elif type(start_section) is int:
        text_start_index = positions[start_section]

    text_end_index = len(full_text)
    if type(end_section) is str or type(end_section) is unicode:
        text_end_index = positions[headings.index(end_section)]
    elif type(end_section) is int:
        text_end_index = positions[end_section]

    res = regex.search(full_text[text_start_index:text_end_index])
    results = regex.finditer(full_text[text_start_index:text_end_index])
    if res:
        for r in results:
            (s, e) = r.span()
            resultobj = TestResult(test_label, bool(res), position=(text_start_index + s, text_start_index + e))
            if report_immediately:
                tell_penelope(resultobj)
            result_objects.append(resultobj)
            # Report the test and the match
            print_to_console(u"'{0}' found '{1}'".format(test_label, r.group()))
    else:
        resultobj = TestResult(test_label, bool(res))
        if report_immediately:
            tell_penelope(resultobj)
        result_objects.append(resultobj)

    return result_objects


def get_sections(full_text):
    """ Use the title regex to break a document into sections, returning the headings and their character indexes """
    match_md_heading = re.compile("^#+.+?$")
    match_md_italic = re.compile("^[*_]\n?.+?[*_]$")
    match_md_bold = re.compile("^\*\*\n?.+?\*\*$|^__\n?.+?__$")
    match_heading_shortness = re.compile("^[-\w\d :?!;'–]+$")

    match_any_heading = re.compile('(?:{0}|{1}|{2}|{3})'.format(match_md_heading.pattern, match_md_bold.pattern, match_md_italic.pattern, match_heading_shortness.pattern), flags=re.MULTILINE)

    # Create lists of both the document's headings, and their locations in text
    all_headings = match_any_heading.finditer(full_text)
    heading_text_list = ['doc_start']
    heading_start_list = [0]               # due to binning with numpy.digitize(), require bins[i-1] < x <= bins[i]
    if all_headings:
        for h in all_headings:
            heading = h.group()
            heading_text_list.append(heading)
            heading_start_list.append(h.start())
    heading_text_list.append('doc_end')
    heading_start_list.append(len(full_text))

    return heading_text_list, heading_start_list

def get_section_index(full_text, section_title):
    """
    Find the section index which best matches the title we're looking for
    :param full_text: the full text of the document
    :param section_title: a string title heading
    :return: its index in the sections list
    """
    (headings, positions) = get_sections(full_text)

    good_matches = []
    for i in range(0, len(headings)):
        if fuzzy_match(strip_markup(section_title), strip_markup(headings[i])):
            good_matches.append(i)

    # All we can do is get the first one - supply more information to get better matches
    if good_matches:
        return good_matches[0]
    else:
        return None


def fuzzy_match(s1, s2, max_dist=None):
    """
    Decide if one string matches another, by tokenising and stemming the words, and using edit distance.
    :param s1: the string you're interested in
    :param s2: the string you are comparing it to
    :param max_dist:
    :return:
    """
    # Use the NLTK's Porter Stemmer
    stemmer = stem.PorterStemmer()

    # Tokenise and stem the words
    s1_words = tokenize.wordpunct_tokenize(s1.lower().strip())
    normalised_s1 = ' '.join([stemmer.stem(w) for w in s1_words])
    s2_words = tokenize.wordpunct_tokenize(s2.lower().strip())
    normalised_s2 = ' '.join([stemmer.stem(w) for w in s2_words])

    # the default max edit distance - half the mean word length of the shortest sentence
    if not max_dist:
        min_sent = min(s1_words, s2_words, key=len)
        max_dist = sum(map(len, min_sent)) / (len(min_sent) * 2 + 1)

    # Check for edit distance match or substring match
    e_d_match = metrics.edit_distance(normalised_s1, normalised_s2) <= max_dist
    sub_match = normalised_s1 in normalised_s2
    return e_d_match or sub_match


def in_section(position, text=None, heading_info=None):
    """
    Return the most recent section header for the character index
    :param position: character index
    :return: the section title
    """

    # if not given the heading information, find it now.
    if text and not heading_info:
        (headings, position_bins) = get_sections(text)
    elif heading_info:
        (headings, position_bins) = heading_info
    else:
        return None

    binning_result = digitize([position], position_bins)
    binned_position = binning_result.tolist().pop()
    return headings[binned_position - 1]


def find_in_title_or_section(regex, text, test_label, report_immediately=True):
    """
    Checks if a regex matches a section heading. If not, checks if it matches in section, and returns that section heading.
    :param regex: the compiled regular expression to test for
    :param text: the full text of the document
    :param test_label: the label this test will be reported back as
    :return: a list of TestResults, as defined in penelope_com
    """
    # check for regex in titles
    result = find_in_title(regex, text, test_label, report_immediately=False)

    # check the whole text if not in titles
    if result.passed:
        if report_immediately:
            tell_penelope(result)
        return [result]
    else:
        result_objects = title_of_section_match(regex, text, test_label, report_immediately=report_immediately)
        return result_objects


def find_in_title(regex, text, test_label, report_immediately=True):
    """
    Checks if a regex matches a section heading.
    :param regex: the compiled regular expression to test for
    :param text: the full text of the document
    :param test_label: the label this test will be reported back as
    :return: a TestResult, as defined in penelope_com, with pass/fail only
    """

    (headings, positions) = get_sections(text)

    matches = []
    for heading in headings:
        res = regex.search(heading)
        matches.append(bool(res))
        if res:
            # Report which heading matched the regex
            print_to_console(u"'{0}' found in the heading '{1}'".format(res.group(), heading))

    resultobj = TestResult(test_label, any(matches))
    if report_immediately:
        tell_penelope(resultobj)
    return resultobj


def title_of_section_match(regex, text, test_label, report_immediately=True):
    """
    Checks if a regex matches in any section, and returns that section heading.
    :param regex: the compiled regular expression to test for
    :param text: the full text of the document
    :param test_label: the label this test will be reported back as
    :return: a list of TestResults, as defined in penelope_com
    """
    (headings, positions) = get_sections(text)

    result_objects = []
    res = regex.search(text)
    results = regex.finditer(text)
    if res:
        for r in results:
            resultobj = TestResult(test_label, bool(res), position=r.span())
            if report_immediately:
                tell_penelope(resultobj)
            result_objects.append(resultobj)
            # Report in which section we have found the matches
            print_to_console(u"'{0}' found in the section '{1}'".format(r.group(), in_section(r.start(), heading_info=(headings, positions))))
    else:
        resultobj = TestResult(test_label, bool(res))
        if report_immediately:
            tell_penelope(resultobj)
        result_objects.append(resultobj)

    return result_objects

def strip_markup(text):
    """Remove markup and whitespace either side of a string"""
    match_markup = re.compile(r'\s*[#*_]+\s*')

    # Use max-length string in split text (other entries should be 0-length for each markup match)
    text_only = max(match_markup.split(text), key=len)
    return text_only

def extract_headings(text, test):
    """Extract the headings from the given text"""
    ## Make regex for formatted headings
    formatted_headings = re.compile(r"[\*\#\_]+(?:\s)?.{2,200}?(?:\s)?[\*\#\_]+", flags = re.DOTALL)

    ## Make regex for unformatted headings
    ## First we accept more than just a new line. Some authors label headings with
    ## an asterix, hash, or a superscript symbol or html inside <>
    # start_of_line = r"^\s*(?:\*|\#|\[|(<.+?>)(\.{0,3}<.+?>)*|\d[\)\.\d]*|(?:\!\[\]\(.*\)))*" # deleted this because it was taking too long
    triangles = r"(<.*>)[(.*{0,10})<.*>|<.*>]*" # this is to catch stuff in html
    start_of_line = r"^\s*(?:\*|\#|\[|"+triangles+"|\d[\)\.\d]*|(?:\!\[\]\(.*\)))*"
    end_of_heading = r"[:;.!?\n]"
    short_headings = re.compile(start_of_line+r"[\w\d\s\-'–]{4,50}?"+end_of_heading)

    ## Put heading regex together
    heading_regex = re.compile(r"(?:{0}|{1})".format(formatted_headings.pattern, short_headings.pattern), flags=re.MULTILINE)
    raw_headings = find_in_full_text(heading_regex, text, test)
    return raw_headings

def strip_punc(string):
    """Remove punctuation from the given string"""
    strip_punc_pattern = re.compile(r"[^a-zA-Z0-9_\s]")
    stripped_string = strip_punc_pattern.sub("", string)
    return stripped_string

def clean_string(string):
    """Normalise the given string"""
    string = strip_punc(string)
    string = string.lower()
    string = re.sub(r"^[\d\.\s]+", "", string) # removes numbers from start. Important for manuscripts with line numbers.
#     string = re.sub(triangles, "", string) # removes things between < and >
    return string

def match_headings(heading_to_match, heading_obj_list, text):
    """Clean up the string and see if the required heading is present"""
	found = []
	regex = heading_to_match
	for h in heading_obj_list:
		h_text = text[h.position[0]:h.position[1]]
		h_text = clean_string(h_text.strip())
		match = regex.search(h_text)
		if match:
			found.append(h)
	return found

def find_heading_occurance(heading_objs, text, heading_to_match, first_or_last = 0, early_start_pos = None, latest_end_point = None):
    """Clean up the string and see if the required heading is present"""
    e = early_start_pos
    l = latest_end_point
    # first or last should be 0 or -1
    results = None
    headings = match_headings(heading_to_match, heading_objs, text)
    if (e or l):
    	if not e:
    		e = 0
    	if not l:
    		l = len(text) - 1
    	new_headings = [h for h in headings if ((h.position[0] > e) and (h.position[1]<l))]
    	headings = new_headings
    if headings:
        result = headings[first_or_last]
    return result
