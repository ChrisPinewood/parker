#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Helpers dealing with references in a document
"""
from parker.penelope_com import warn_penelope
import re

def get_reference_numbers(text):
    """ extract a list of reference numbers from text """
    match_ref = re.compile(r'^[#*_]*\d+\. *.*?$', flags=re.MULTILINE)

    ints = []
    res = match_ref.finditer(text)
    for r in res:
        # find the first number group (the reference's number)
        ref = r.group()
        num = re.search('\d+', ref).group()
        ints.append(int(num))

    return ints

def parse_numbered_citation(citation):
    """
    (helper function) Get a list of integers for a numbered citation (bracketed or superscript), including enumerating ranges
    :param citation: a single numbered citation string, e.g. '[5-8, 11]'
    :return: a list of integers referred to, e.g. [5, 6, 7, 8, 11]
    """
    stripped = re.sub('\.*<sup>|</sup>|\[|\]|\(|\)|\\\\', '', citation)

    ints = []
    for s in re.split('[,; ]+', stripped):
        try:
            i = int(s)
            ints.append(i)
        except ValueError:
            match_dashes = re.compile('[- –]+')
            if match_dashes.search(s):
                # we have a range; enumerate it
                split = match_dashes.split(s)
                (start, end) = (split.pop(0), split.pop())
                if start.isdigit() and end.isdigit():
                    ints.extend(range(int(start), int(end) + 1))
    return ints

def get_citation_numbers(text):
    """ extract a list of citation numbers from text """
    match_num = re.compile(r'(\[[-\d,; –]+\\?\])|(<sup>[-\d,; –]+</sup>)|(\([-\d,; –]+\))')

    res = match_num.finditer(text)

    ints = []
    for r in res:
        ints.append(parse_numbered_citation(r.group()))

    # Flatten out the returned list
    return [y for x in ints for y in x]
