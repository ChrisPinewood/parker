from setuptools import setup, find_packages

setup(
    name = 'Parker',
    version = '0.17',
    packages = find_packages(),
    install_requires = [
        "requests",
        "xmltodict",
        "argparse",
        "numpy",
        "nltk",
        "colorama",
    ],
    url = 'http://www.peneloperesearch.com/',
    author = 'Steve Eardley',
    author_email = 'steve@cottagelabs.com',
    description = 'Serve Penelope with Python tests'
)
# To build distributable:
#   python setup.py sdist
