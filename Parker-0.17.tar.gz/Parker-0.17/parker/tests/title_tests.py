#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Tests on a document's titles"""

import parker.penelope_com as penelope_com
from parker.document import find_in_title_or_section, strip_markup, find_in_full_text, extract_headings, find_heading_occurance
from parker.penelope_com import print_to_console, compare_results, TestResult, tell_penelope
import re

### MAIN TESTS FOR PENELOPE

def find_abstract(text, report_immediately=True):
    """ find the abstract in a doc """
    return _find_section("abstract", "find_abstract", report_immediately)

def find_acknowledgements(text, report_immediately=True):
    """ find the acknowledgements in a doc """
    return _find_section("acknowledgements", "find_acknowledgements", report_immediately)

def find_competing_interests(text, report_immediately=True):
    """ find the competing interests section in a doc """
    return _find_section("conflicting_interests", "find_competing_interests", report_immediately)

def find_discussion(text, report_immediately=True):
    """ find the discussion in a doc """
    return _find_section("discussion", "find_discussion", report_immediately)

def find_conclusion(text, report_immediately=True):
    """ find the conclusion in a doc """
    return _find_section("conclusion", "find_conclusion", report_immediately)

def find_introduction(text, report_immediately=True):
    """ find the introduction in a doc """
    return _find_section("introduction", "find_introduction", report_immediately)

def find_methods(text, report_immediately=True):
    """ find the methods in a doc """
    return _find_section("methods", "find_methods", report_immediately)

def find_references(text, report_immediately=True):
    """ find the references in a doc """
    return _find_section("references", "find_references", report_immediately)

def find_results(text, report_immediately=True):
    """ find the results in a doc """
    return _find_section("results", "find_results", report_immediately)

def find_data_access_statement(text, report_immediately=True):
    """ find the data access statement in a doc """
    return _find_section("data_statement", "find_data_access_statement", report_immediately)

def find_funding(text, report_immediately=True):
    """ find the funding statement in a doc """
    return _find_section("funding_statement", "find_funding", report_immediately)

def find_ethics(text, report_immediately=True):
    """ find the ethics statement in a doc """
    match_ethics = re.compile(r'\bethics\b', flags=re.IGNORECASE | re.MULTILINE)
    return find_in_title_or_section(match_ethics, text, 'find_ethics', report_immediately)

def find_introduction_after_abstract(text, report_immediately=True):
    """ find the introduction after the abstract section """
    # Get the last introduction
    (introStart, introEnd) = _find_pos_of_section('introduction', False)
    (abstractStart, abstractEnd) = _find_pos_of_section('abstract')

    if introStart > abstractEnd:
        result = TestResult('find_introduction_after_abstract', True)
    else:
        result = TestResult('find_introduction_after_abstract', False, (introStart, introEnd))

    if report_immediately:
        tell_penelope(result)

    return [result]

def find_methods_in_main_body(text, report_immediately=True):
    if _find_section_in_main_body('methods'):
        result = TestResult('find_methods_in_main_body', True)
    else:
        result = TestResult('find_methods_in_main_body', False)

    if report_immediately:
        tell_penelope(result)

    return [result]

def find_results_in_main_body(text, report_immediately=True):
    if _find_section_in_main_body('results'):
        result = TestResult('find_results_in_main_body', True)
    else:
        result = TestResult('find_results_in_main_body', False)

    if report_immediately:
        tell_penelope(result)

    return [result]

def find_discussion_in_main_body(text, report_immediately=True):
    if _find_section_in_main_body('discussion'):
        result = TestResult('find_discussion_in_main_body', True)
    else:
        result = TestResult('find_discussion_in_main_body', False)

    if report_immediately:
        tell_penelope(result)

    return [result]

def find_purpose_in_abstract_body(text, report_immediately=True):
    if _find_section_in_abstract('purpose'):
        result = TestResult('find_purpose_in_abstract_body', True)
    else:
        result = TestResult('find_purpose_in_abstract_body', False)

    if report_immediately:
        tell_penelope(result)

    return [result]

def find_methods_in_abstract_body(text, report_immediately=True):
    if _find_section_in_abstract('methods'):
        result = TestResult('find_methods_in_abstract_body', True)
    else:
        result = TestResult('find_methods_in_abstract_body', False)

    if report_immediately:
        tell_penelope(result)

    return [result]

def find_results_in_abstract_body(text, report_immediately=True):
    if _find_section_in_abstract('results'):
        result = TestResult('find_results_in_abstract_body', True)
    else:
        result = TestResult('find_results_in_abstract_body', False)

    if report_immediately:
        tell_penelope(result)

    return [result]

def find_conclusion_in_abstract_body(text, report_immediately=True):
    if _find_section_in_abstract('conclusion'):
        result = TestResult('find_conclusion_in_abstract_body', True)
    else:
        result = TestResult('find_conclusion_in_abstract_body', False)

    if report_immediately:
        tell_penelope(result)

    return [result]

### TESTS / TOOLS FOR CONSOLE

def _find_section_in_abstract(section):
    if section not in penelope_com.extracted_headings:
        return False

    (abstractStart, abstractEnd) = _find_pos_of_section('abstract', False)
    (introStart, introEnd) = _find_pos_of_section('introduction', False)

    headingPositions = penelope_com.extracted_headings[section]
    return _section_between(headingPositions, abstractEnd, introStart)

def _find_section_in_main_body(section):
    if section not in penelope_com.extracted_headings:
        return False

    (introStart, introEnd) = _find_pos_of_section('introduction', False)
    (refStart, refEnd) = _find_pos_of_section('references', False)

    headingPositions = penelope_com.extracted_headings[section]
    return _section_between(headingPositions, introEnd, refStart)

def _section_between(headings, start, end):
    for (headingStart, headingEnd) in headings:
        if headingStart > start and headingEnd < end:
            return True

    return False

def _find_pos_of_section(section, first=True):
    return penelope_com.extracted_headings[section][0 if first else -1]

def _find_section(section, test, report_immediately):
    """ If the given section key is found in the extracted headings then we have it in our document """
    if section in penelope_com.extracted_headings:
        result = TestResult(test, True)
    else:
        result = TestResult(test, False)

    if report_immediately:
        tell_penelope(result)

    return [result]

def compare_title_regexes(text):
    """ (console only) Comparing regexes to improve title discovery"""

    #todo: a work in progress - attempting to change the '.+?' with something that's just non-whitespace (while allowing spaces)
    match_md_heading = re.compile(r"^#+[^\t\n\r\f\v]+?$")
    match_md_italic = re.compile(r"^[*_][^\t\n\r\f\v]+?[*_]$")
    match_md_bold = re.compile(r"^\*\*[^\t\n\r\f\v]+?\*\*$|^__[^\t\n\r\f\v]+?__$")
    match_heading_shortness = re.compile(r"^[^\t\n\r\f\v]+$")

    match_any_heading_new = re.compile(r'(?:{0}|{1}|{2}|{3})'.format(match_md_heading.pattern, match_md_bold.pattern, match_md_italic.pattern, match_heading_shortness.pattern), flags=re.MULTILINE)
    res = find_in_full_text(match_any_heading_new, text, 'match_any_heading_new', False)

    match_md_heading1 = re.compile("^#+.+?$")
    match_md_italic1 = re.compile("^[*_]\n?.+?[*_]$")
    match_md_bold1 = re.compile("^\*\*\n?.+?\*\*$|^__\n?.+?__$")
    match_heading_shortness1 = re.compile("^[-\w\d :?!;'–]+$")

    match_any_heading_old = re.compile('(?:{0}|{1}|{2}|{3})'.format(match_md_heading1.pattern, match_md_bold1.pattern, match_md_italic1.pattern, match_heading_shortness1.pattern), flags=re.MULTILINE)
    res1 = find_in_full_text(match_any_heading_old, text, 'match_any_heading_old', False)

    compare_results(text, [res, res1])

def title_lengths(text):
    """ (console only) provide a report on the titles and lengths in a document """
    match_md_heading = re.compile("^#+.+?$")
    match_md_italic = re.compile("^[*_]\n?.+?[*_]$")
    match_md_bold = re.compile("^\*\*\n?.+?\*\*$|^__\n?.+?__$")
    match_heading_shortness = re.compile("^[-\w\d :?!;'–]+$")

    match_any_heading = re.compile('(?:{0}|{1}|{2}|{3})'.format(match_md_heading.pattern, match_md_bold.pattern, match_md_italic.pattern, match_heading_shortness.pattern), flags=re.MULTILINE)
    all_headings = match_any_heading.finditer(text)

    n_main = n_sub = n_all = 0

    print_to_console('length\ttype\theading')
    for heading in all_headings:
        n_all += 1

        # Use max-length string in split text (other entries should be 0-length for each markup match)
        heading_text_only = strip_markup(heading.group())
        if match_md_bold.search(heading.group()) or match_md_italic.search(heading.group()):
            n_sub += 1
            print_to_console(u"{1}\tsub\t'{0}'".format(heading_text_only, len(heading_text_only)))
        else:
            n_main += 1
            print_to_console(u"{1}\tmain\t'{0}'".format(heading_text_only, len(heading_text_only)))

    print_to_console(u'\n{0} heading(s) found; {1} main heading(s) and {2} subheading(s).'.format(n_all, n_main, n_sub))
