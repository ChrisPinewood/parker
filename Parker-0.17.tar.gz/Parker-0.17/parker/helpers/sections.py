#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This is the list of section regexs
"""

import re

# This is the only public facing method.
# Given the markdown document is will return an associative array with section_regexs key as the key
# and the positions where there was a match (there could be multiple):
#   headings[key] = [(start 1, end 1), (start 2, end 2), ... (start n, end n)]
# eg (in JSON),
#   headings = {
#     "title" : [(0, 8)],
#     "results" : [(123, 136), (485, 495)]
#   }

def extract_headings(text):
    """ find and return all headings in a file as array """
    all_headings = heading_regex.finditer(text)
    cleaned = _cleaned_results(all_headings, text)

    headings = {}

    for key, value in section_regexs.iteritems():
        for ckey, cvalue in cleaned:
            results = value.finditer(ckey)
            for r in results:
                (start, end) = cvalue.span()
                if key not in headings:
                    headings[key] = []
                headings[key].append((start, end))

    return headings


formatted_headings = r"[\*\#\_]+(?:\s)?.{2,200}?(?:\s)?[\*\#\_]+"

## Make regex for unformatted headings
## First we accept more than just a new line. Some authors label headings with
## an asterix, hash, or a superscript symbol or html inside <>
# start_of_line = r"^\s*(?:\*|\#|\[|(<.+?>)(\.{0,3}<.+?>)*|\d[\)\.\d]*|(?:\!\[\]\(.*\)))*" # deleted this because it was taking too long
triangles = r"(<.*>)[(.*{0,10})<.*>|<.*>]*" # this is to catch stuff in html
start_of_line = r"^\s*(?:\*|\#|\[|" + triangles + "|\d[\)\.\d]*|(?:\!\[\]\(.*\)))*"
end_of_heading = r"[:;.!?\n]"
short_headings = start_of_line + r"[\w\d\s\-'–]{4,50}?" + end_of_heading


## ALL REGEXES PUT INTO A DICTIONARY
strip_punc_pattern = re.compile(r"[^a-zA-Z0-9_\s]")
heading_regex =  re.compile(r"(?:{0}|{1})".format(formatted_headings, short_headings), flags=re.MULTILINE)
section_regexs = {
    "title": re.compile(r"^title", flags = re.IGNORECASE),
    "running_head": re.compile(r"(Running\s*Head|Running\s*Title|Alternative\s*Head|Alternative\s*Title)", flags = re.IGNORECASE),
    "authors": re.compile(r"(^Authors*\s+(?!affiliation|contribution)|List\s*of\s*Authors)", flags = re.IGNORECASE),
    "corresponding_author": re.compile(r"(send|ad+res+\s+)*(Cor+espond([ea]nce|ing)\s*(author|to)|E[\-\s+]Mail)", flags = re.IGNORECASE),
    "word_count": re.compile(r"(Word\s*Counts?|Words)", flags = re.IGNORECASE),
    "author_Statement": re.compile(r"(Authors?\s*(Statements?|contributions?))", flags = re.IGNORECASE),
    "conflicting_interests": re.compile(r"^(declarations?\s*|statements?\s*)of\s*(compete?ing|conflicting)?\s*interests?|(compete?ing|conflict[sing]*)\s*interests?|disclosure", flags = re.IGNORECASE),
    "data_statement": re.compile(r"(data\s*statement|data\s*access\s*statement|data\s*availability\s*statement)", flags = re.IGNORECASE),
    "funding_statement": re.compile(r"(Sources?\s*of\s*Funding|Funding)", flags = re.IGNORECASE),
    "abstract": re.compile(r"(Abstract)", flags = re.IGNORECASE),
    "introduction": re.compile(r"(Introduction|background|rationale|purpose)", flags = re.IGNORECASE),
    "methods": re.compile(r"^(research\s*)?(Methods?|Materials?\s*and\s*Methods?|Methods?\s*and\s*Materials?\s*)", flags = re.IGNORECASE),
    "results": re.compile(r"(^(analys[ei]s\s(and|&)\s)?results?)", flags = re.IGNORECASE),
    "discussion": re.compile(r"(Discus+ion)", flags = re.IGNORECASE),
    "references": re.compile(r"(^References?|bib+liography)", flags = re.IGNORECASE),
    "acknowledgements": re.compile(r"(A[ck]+no[wledge]+ments?)", flags = re.IGNORECASE),
    "conclusion": re.compile(r"(conclusions?)", flags = re.IGNORECASE),
    "purpose": re.compile(r"(purpose)", flags = re.IGNORECASE),
    "appendix": re.compile(r"(Appendix|Sup+l[ie]ment(ary)?\s*(info(rmation)?|files?|materials?|videos?))", flags = re.IGNORECASE)
}

def _strip_punc(string):
    stripped_string = strip_punc_pattern.sub("", string)
    return stripped_string

def _clean_string(string):
    string = _strip_punc(string)
    string = string.lower()
    string = re.sub(r"^[\d\.\s]+", "", string) # removes numbers from start. Important for manuscripts with line numbers.
    return string

def _cleaned_results(headings, text):
    """ Return the cleaned version of strings with their original results """
    cleaned = []
    for h in headings:
        (start, end) = h.span()
        h_text = text[start:end]
        h_text = _clean_string(h_text.strip())
        cleaned.append((h_text, h))

    return cleaned
